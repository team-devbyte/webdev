/*-----------Script for toggle menu bar in small devices------------------*/
let icon =document.querySelector(".icon");
let ul =document.querySelector("ul");

icon.addEventListener("click", ()=>{
    ul.classList.toggle("showData");
    // console.log(ul);
})


/*-------------Script for social media toggle menu-------------------*/
let toggle = document.querySelector('.toggle');
let menu = document.querySelector('.t-menu');
toggle.onclick = function(){
    menu.classList.toggle('active')
}



/*-------------Script for text reveal-------------------------------*/
ScrollReveal({
    reset: false,
    distance: '100px',
    duration: 2000,
    delay: 400
});

ScrollReveal().reveal('.greating-heading',{ delay: 200, origin: 'top'});
ScrollReveal().reveal('.sub-heading1',{ delay: 200, origin: 'right'});
ScrollReveal().reveal('.para',{ delay:100, origin: 'bottom'});
ScrollReveal().reveal('.left',{ delay: 400, origin: 'left'});
ScrollReveal().reveal('.container',{ delay: 400, origin: 'right', interval:200});
ScrollReveal().reveal('.skill-txt',{ delay: 400, origin: 'right', interval:200});
ScrollReveal().reveal('.box',{ delay: 200, origin: 'top', interval:200});
ScrollReveal().reveal('.form-controls',{ delay: 100, origin: 'left', interval:100});